import { HomeScrollProvider } from "@/components/features/home/HomeScrollProvider";

export default function Home() {
  return <HomeScrollProvider />;
}
