"use client";

import { motion } from 'framer-motion';
import { DSHeading, DSText, DSContainer, DSDecorativeAsterisk } from '@/components/ui/design-system';
import { categoryThemes } from '@/data/artworks';
import Link from 'next/link';

interface CategoryHeaderProps {
    category: keyof typeof categoryThemes;
}

export const CategoryHeader = ({ category }: CategoryHeaderProps) => {
    const theme = categoryThemes[category];

    return (
        <section className="pt-40 pb-20 relative">
            <div className="flex flex-col items-center text-center max-w-4xl mx-auto px-6">
                <motion.div
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.8 }}
                    className="mb-4"
                >
                    <span className="text-[10px] tracking-[0.4em] uppercase font-medium text-muted-foreground">
                        {theme.title}
                    </span>
                </motion.div>

                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.8, delay: 0.1 }}
                    className="space-y-8"
                >
                    <DSHeading level="h1" className="text-3xl md:text-5xl lg:text-5xl tracking-widest uppercase font-light leading-tight">
                        {theme.subtitle}
                    </DSHeading>

                    <DSDecorativeAsterisk className="mx-auto opacity-20" />
                </motion.div>
            </div>

            <div className="mt-12 border-y border-border/10 py-6 relative z-30">
                <DSContainer>
                    <div className="flex justify-center flex-wrap gap-8 md:gap-32 text-[9px] tracking-[0.3em] uppercase font-semibold text-muted-foreground">
                        {theme.subnav.map((item, index) => {
                            const label = typeof item === 'string' ? item : item.label;
                            const href = typeof item === 'string' ? null : item.href;

                            const content = (
                                <>
                                    {label}
                                    <span className={`absolute -bottom-1 left-0 w-full h-px bg-foreground transition-transform origin-left ${index === 0 ? 'scale-x-100' : 'scale-x-0 group-hover:scale-x-100'}`} />
                                </>
                            );

                            const className = `hover:text-foreground transition-colors relative group py-2 ${index === 0 ? 'text-foreground' : ''}`;

                            if (href) {
                                return (
                                    <Link key={label} href={href} className={className}>
                                        {content}
                                    </Link>
                                );
                            }

                            return (
                                <button key={label} className={className}>
                                    {content}
                                </button>
                            );
                        })}
                    </div>
                </DSContainer>
            </div>

            {/* Ambient Background */}
            <div className={`absolute inset-0 bg-gradient-to-b ${theme.accentColor} -z-10`} />
        </section>
    );
};
