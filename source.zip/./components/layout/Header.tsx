"use client";

import { useState, useCallback } from "react";
import { siteConfig, navigationConfig } from "@/data/site-config";
import { cn } from "@/lib/utils";
import { Z_INDEX } from "@/lib/constants";
import { DSLabel } from "@/components/ui/design-system";
import { ExpertHelpModal } from "@/components/modals/ExpertHelpModal";
import { MessageCircle } from "lucide-react";

// =============================================================================
// Header Component
// =============================================================================

/**
 * Fixed header with responsive navigation
 * Refactored to use DSLabel for unified typography.
 */
const Header = () => {
    const [isMenuOpen, setIsMenuOpen] = useState(false);
    const [isExpertModalOpen, setIsExpertModalOpen] = useState(false);

    const toggleMenu = useCallback(() => {
        setIsMenuOpen(prev => !prev);
    }, []);

    const closeMenu = useCallback(() => {
        setIsMenuOpen(false);
    }, []);

    return (
        <>
            <header
                className="fixed top-0 left-0 right-0 bg-background/60 backdrop-blur-lg"
                style={{ zIndex: Z_INDEX.header }}
            >
                {/* Main Header Bar */}
                <div className="flex items-center justify-between px-6 py-5 md:px-12 lg:px-16 border-b border-black/5">
                    {/* Logo */}
                    <Logo />

                    {/* Desktop Navigation */}
                    <DesktopNav />

                    {/* Right Side Actions */}
                    <div className="flex items-center justify-end gap-6 md:gap-10 flex-shrink-0">
                        {/* Expert Help Button */}
                        <button
                            onClick={() => setIsExpertModalOpen(true)}
                            className="hidden md:flex items-center gap-2 group"
                        >
                            <MessageCircle size={14} className="text-muted-foreground group-hover:text-accent transition-colors" />
                            <DSLabel className="group-hover:text-accent transition-colors">
                                ПОМОЩЬ
                            </DSLabel>
                        </button>
                        <MenuToggle isOpen={isMenuOpen} onToggle={toggleMenu} />
                    </div>
                </div>

                {/* Mobile Navigation Dropdown */}
                {isMenuOpen && (
                    <MobileNav
                        onNavClick={closeMenu}
                        onExpertClick={() => {
                            closeMenu();
                            setIsExpertModalOpen(true);
                        }}
                    />
                )}
            </header>

            {/* Expert Help Modal */}
            <ExpertHelpModal
                isOpen={isExpertModalOpen}
                onClose={() => setIsExpertModalOpen(false)}
            />
        </>
    );
};

// =============================================================================
// Sub-components
// =============================================================================

const Logo = () => (
    <div className="flex-shrink-0">
        <a
            href="/"
            className="font-display text-2xl tracking-tighter hover:opacity-70 transition-opacity whitespace-nowrap italic"
        >
            {siteConfig.name}
        </a>
    </div>
);

const DesktopNav = () => (
    <nav className="hidden xl:flex items-center justify-center gap-10 mx-4">
        {navigationConfig.map((item) => (
            <NavLink key={item.name} href={item.href}>
                {item.name}
            </NavLink>
        ))}
    </nav>
);

interface NavLinkProps {
    href: string;
    children: string;
    className?: string;
    onClick?: () => void;
}

const NavLink = ({ href, children, className, onClick }: NavLinkProps) => (
    <a
        href={href}
        className={cn(
            "group relative block overflow-hidden",
            className
        )}
        onClick={onClick}
    >
        <DSLabel className="hover:text-accent transition-colors duration-300">
            {children}
        </DSLabel>
        <span className="absolute bottom-0 left-0 w-full h-px bg-accent scale-x-0 group-hover:scale-x-100 transition-transform duration-300 origin-left" />
    </a>
);

interface MenuToggleProps {
    isOpen: boolean;
    onToggle: () => void;
}

const MenuToggle = ({ isOpen, onToggle }: MenuToggleProps) => (
    <button
        className="xl:hidden group"
        onClick={onToggle}
        aria-label={isOpen ? "Закрыть меню" : "Открыть меню"}
        aria-expanded={isOpen}
    >
        <DSLabel className="group-hover:text-accent transition-colors">
            {isOpen ? "ЗАКРЫТЬ" : "МЕНЮ"}
        </DSLabel>
    </button>
);

interface MobileNavProps {
    onNavClick: () => void;
    onExpertClick: () => void;
}

const MobileNav = ({ onNavClick, onExpertClick }: MobileNavProps) => (
    <nav className="xl:hidden bg-background/90 backdrop-blur-xl border-b border-border fixed inset-x-0 top-[73px]">
        <div className="flex flex-col px-6 py-12 gap-8 items-center text-center">
            {navigationConfig.map((item) => (
                <NavLink
                    key={item.name}
                    href={item.href}
                    onClick={onNavClick}
                >
                    {item.name}
                </NavLink>
            ))}
            {/* Expert Help in mobile menu */}
            <button
                onClick={onExpertClick}
                className="flex items-center gap-2 group"
            >
                <MessageCircle size={14} className="text-muted-foreground group-hover:text-accent transition-colors" />
                <DSLabel className="group-hover:text-accent transition-colors">
                    ПОМОЩЬ ЭКСПЕРТОВ
                </DSLabel>
            </button>
        </div>
    </nav>
);

export default Header;
