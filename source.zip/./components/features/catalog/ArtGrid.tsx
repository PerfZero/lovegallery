"use client";

import { type Artwork } from '@/data/artworks';
import { ArtCard } from './ArtCard';

interface ArtGridProps {
    artworks: Artwork[];
}

export const ArtGrid = ({ artworks }: ArtGridProps) => {
    const isPetFurniture = artworks.length > 0 && artworks[0].category === 'pet-furniture';
    const isCollections = artworks.length > 0 && artworks[0].category === 'collections';

    return (
        <div className="flex-1">
            <div className={`grid grid-cols-1 md:grid-cols-2 ${isPetFurniture ? 'lg:grid-cols-4' : isCollections ? 'lg:grid-cols-1 max-w-4xl mx-auto' : 'lg:grid-cols-3'} gap-x-8 gap-y-24`}>
                {artworks.map((artwork, index) => {
                    const columns = isPetFurniture ? 4 : isCollections ? 1 : 3;

                    let staggeredClass = '';
                    if (!isPetFurniture && !isCollections) {
                        staggeredClass = index % 3 === 1 ? 'md:translate-y-24' : index % 3 === 2 ? 'md:translate-y-12' : '';
                    }

                    return (
                        <div
                            key={artwork.id}
                            className={staggeredClass}
                        >
                            <ArtCard artwork={artwork} index={index} />
                        </div>
                    );
                })}
            </div>

            {/* Pad the bottom of the staggered grid */}
            {!isCollections && <div className="h-48 hidden md:block" />}
        </div>
    );
};
